//
//  ViewController.swift
//  StaticFrameworkUsed
//
//  Created by EZen on 2022/2/15.
//

import UIKit


class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

