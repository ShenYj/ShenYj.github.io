/* A.h */
#ifdef ENABLE_A
void a() {}
#endif
