//
//  OCClass.m
//  OCSDK
//
//  Created by EZen on 2022/2/23.
//

#import "OCClass.h"

@implementation OCClass

+ (void)oc_func1
{
    NSLog(@"%s", __func__);
}

+ (void)oc_func2
{
    NSLog(@"%s", __func__);
}

- (void)oc_func3:(int)number1 number2:(int)number2
{
    NSLog(@"%s %d + %d = %d", __func__, number1, number2, number1 + number2);
}


@end
