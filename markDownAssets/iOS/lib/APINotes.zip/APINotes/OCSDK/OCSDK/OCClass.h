//
//  OCClass.h
//  OCSDK
//
//  Created by EZen on 2022/2/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface OCClass : NSObject

+ (void)oc_func1;
+ (void)oc_func2;
- (void)oc_func3:(int)number1 number2:(int)number2;

@end

NS_ASSUME_NONNULL_END
