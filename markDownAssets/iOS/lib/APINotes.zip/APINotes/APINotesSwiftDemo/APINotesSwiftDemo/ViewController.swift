//
//  ViewController.swift
//  APINotesSwiftDemo
//
//  Created by EZen on 2022/2/23.
//

import UIKit
import OCSDK

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        // 使用 .apinotes 配置后
        SDKClass.oc_func1()
        SDKClass.oc_func2()
        let sdkInstance = SDKClass()
        sdkInstance.func3(1, number2: 3)
        
        // 使用 .apinotes 配置前
        OCClass.oc_func1()
        OCClass.oc_func2()
        let ocClassInstance = OCClass()
        ocClassInstance.oc_func3(1, number2: 3)

    }

}

