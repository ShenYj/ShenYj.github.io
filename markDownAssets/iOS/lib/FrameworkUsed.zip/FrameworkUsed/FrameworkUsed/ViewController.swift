//
//  ViewController.swift
//  FrameworkUsed
//
//  Created by EZen on 2022/2/15.
//

import UIKit
import DashLine

class ViewController: UIViewController {
    
    private var dashLine: DashLine?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //dashLine = DashLine()
        if let dashLine = dashLine {
            dashLine.frame = CGRect(x: 20, y: 100, width: UIScreen.main.bounds.width - 40, height: 2)
            view.addSubview(dashLine)
        }
        
        dashLine?.updateLine()
    }
}

