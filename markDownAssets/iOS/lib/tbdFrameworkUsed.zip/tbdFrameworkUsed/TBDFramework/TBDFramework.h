//
//  TBDFramework.h
//  TBDFramework
//
//  Created by EZen on 2022/2/22.
//

#import <Foundation/Foundation.h>

//! Project version number for TBDFramework.
FOUNDATION_EXPORT double TBDFrameworkVersionNumber;

//! Project version string for TBDFramework.
FOUNDATION_EXPORT const unsigned char TBDFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TBDFramework/PublicHeader.h>


