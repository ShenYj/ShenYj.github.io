//
//  TBDTool.m
//  TBDFramework
//
//  Created by EZen on 2022/2/22.
//

#import "TBDTool.h"

@implementation TBDTool

- (void)tbd_framework_func
{
    NSLog(@"%s", __func__);
}

@end
