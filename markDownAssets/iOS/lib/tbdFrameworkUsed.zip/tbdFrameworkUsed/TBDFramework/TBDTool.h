//
//  TBDTool.h
//  TBDFramework
//
//  Created by EZen on 2022/2/22.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TBDTool : NSObject

- (void)tbd_framework_func;

@end

NS_ASSUME_NONNULL_END
