//
//  SceneDelegate.h
//  tbdFrameworkUsed
//
//  Created by EZen on 2022/2/22.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

